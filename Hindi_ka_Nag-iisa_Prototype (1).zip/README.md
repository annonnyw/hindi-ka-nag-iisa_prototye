# Hindi ka Nag-iisa — Prototype

A no-code-free, browser-based prototype based on the provided UI mockups.

## How to run
1. Open `index.html` in a browser.
2. No installation, server, account, or paid service is required.
3. Mood entries and tip submissions are stored locally in the browser using localStorage.

## Included
- Responsive Home dashboard
- Daily Mood Check-In
- Weekly mood summary
- Private-in-this-browser reflection journal prototype
- Peer Coping Library with categories
- Peer tip submission -> Pending Moderation
- Campus Support Directory
- Need Help Now page
- Mobile bottom navigation
- Installable-style web manifest

## Important prototype limitation
This is a local prototype, not a production mental-health platform. It does not provide real authentication, cloud storage, or server-side privacy. Before real student deployment, mood/journal data should be moved to a properly authenticated and access-controlled backend, and all campus/crisis contact information should be verified.

## Suggested next build steps
1. Add an admin moderation dashboard.
2. Add authenticated student accounts.
3. Move mood logs to a secure database with per-user access controls.
4. Add real verified PHINMA-COC support contacts.
5. Conduct usability testing with the target student users.
